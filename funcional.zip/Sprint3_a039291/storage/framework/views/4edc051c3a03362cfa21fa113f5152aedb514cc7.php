
<?php $__env->startSection('menu'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <?php echo Toastr::message(); ?>

    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="mt-5">
                            <h4 class="card-title float-left mt-2">Reservas</h4>
                            <a href="<?php echo e(route('form/booking/add')); ?>" class="btn btn-primary float-right veiwbutton ">Adicionar uma Reserva</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-table">
                        <div class="card-body booking_card">
                            <div class="table-responsive">
                                <table class="datatable table table-stripped table table-hover table-center mb-0">
                                    <thead>
                                        <tr>
                                            <th>ID da Reserva</th>
                                            <th>Reserva em nome de</th>
                                            <th>Tipo de Quarto</th>
                                            <th>Número de Pessoas</th>
                                            <th>Data</th>
                                            <th>Hora</th>
                                            <th>Data de Chegada</th>
                                            <th>Data de Partida</th>
                                            <th>Email</th>
                                            <th>Contacto Telefónico</th>
                                            <th>Status</th>
                                            <th class="text-right">Definições</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td hidden class="id"><?php echo e($bookings->id); ?></td>
                                            <td hidden class="fileupload"><?php echo e($bookings->fileupload); ?></td>
                                            <td><?php echo e($bookings->bkg_id); ?></td>
                                            <td>
                                                <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar avatar-sm mr-2">
                                                    <img class="avatar-img rounded-circle" src="<?php echo e(URL::to('/assets/upload/'.$bookings->fileupload)); ?>" alt="<?php echo e($bookings->fileupload); ?>">
                                                </a>
                                                <a href="profile.html"><?php echo e($bookings->name); ?><span><?php echo e($bookings->bkg_id); ?></span></a>
                                                </h2>
                                            </td>
                                            <td><?php echo e($bookings->room_type); ?></td>
                                            <td><?php echo e($bookings->total_numbers); ?></td>
                                            <td><?php echo e($bookings->date); ?></td>
                                            <td><?php echo e($bookings->time); ?></td>
                                            <td><?php echo e($bookings->arrival_date); ?></td>
                                            <td><?php echo e($bookings->depature_date); ?></td>
                                            <td><a href="#" class="__cf_email__" data-cfemail="2652494b4b5f44435448474a66435e474b564a430845494b"><?php echo e($bookings->email); ?></a></td>
                                            <td><?php echo e($bookings->ph_number); ?></td>
                                            <td>
                                                <div class="actions"> <a href="#" class="btn btn-sm bg-success-light mr-2">Active</a> </div>
                                            </td>
                                            <td class="text-right">
                                                <div class="dropdown dropdown-action">
                                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v ellipse_color"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item" href="<?php echo e(url('form/booking/edit/'.$bookings->bkg_id)); ?>">
                                                            <i class="fas fa-pencil-alt m-r-5"></i> Editar
                                                        </a>
                                                        <a class="dropdown-item bookingDelete" href="#" data-toggle="modal" data-target="#delete_asset">
                                                            <i class="fas fa-trash-alt m-r-5"></i> Apagar
                                                        </a> 
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="delete_asset" class="modal fade delete-modal" role="dialog">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="<?php echo e(route('form/booking/delete')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body text-center"> <img src="<?php echo e(URL::to('assets/img/sent.png')); ?>" alt="" width="50" height="46">
                            <h3 class="delete_class">Tem a certeza que quer eliminar este registo de reserva?</h3>
                            <div class="m-t-20">
                                <a href="#" class="btn btn-white" data-dismiss="modal">Cancelar</a>
                                <input class="form-control" type="hidden" id="e_id" name="id" value="">
                                <input class="form-control" type="hidden" id="e_fileupload" name="fileupload" value="">
                                <button type="submit" class="btn btn-danger">Apagar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
    <?php $__env->startSection('script'); ?>
    
    <script>
        $(document).on('click','.bookingDelete',function()
        {
            var _this = $(this).parents('tr');
            $('#e_id').val(_this.find('.id').text());
            $('#e_fileupload').val(_this.find('.fileupload').text());
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.allbooking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rodmo\Desktop\Sprint3_a039291\resources\views/formbooking/allbooking.blade.php ENDPATH**/ ?>